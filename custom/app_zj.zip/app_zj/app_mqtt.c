#include "app_include.h"
#include <math.h>
#include "cJSON.h"
#include "mg_mqtt.h"
#include "mg_gnss.h"
#include "mg_sim.h"
#include "mg_sys.h"

#define LOG_TAG MAKE_LOG_TAG('U', 'S', 'E', 'R')

#define APP_PUB_TOPIC_DEV_SN    "tank/gpsMsg/"
#define APP_SUB_DOWN_PARAM      "device/ota/"

#if DEBUG_JSON
static char g_tempBuff[512] = {0};
static void app_json_dump(cJSON * root)
{
    char *p = NULL;
    cJSON *item = NULL;

    for(int i = 0; i < cJSON_GetArraySize(root); i++)   //遍历最外层json键值对
    {
        item = cJSON_GetArrayItem(root, i);
        if(cJSON_Object == item->type || cJSON_Array == item->type) //如果对应键的值仍为cJSON_Object就递归调用printJson
        {
            app_json_dump(item);
        }
        else                                //值不为json对象就直接打印出键和值
        {
            p = cJSON_Print(item);
            memset(g_tempBuff, 0x00, sizeof(g_tempBuff));
            if (p) {
                memcpy(g_tempBuff, p, strlen(p));
                free(p);
                p = NULL;
            }

            if (strlen(g_tempBuff)) {
                APP_DEBUG("[%5d]%d..%s->%s", __LINE__, item->type, item->string, g_tempBuff);
            }
            else if (item->valuestring) {
                APP_DEBUG("[%5d]%d..%s->%s", __LINE__, item->type, item->string, item->valuestring);
            }
            else {
                APP_DEBUG("[%5d]%d..%s->%d", __LINE__, item->type, item->string, item->valueint);
                APP_DEBUG("[%5d]%d..%s->%f", __LINE__, item->type, item->string, item->valuedouble);
            }
        }
    }
}
#endif

static char *app_getNetTypeToString(app_net_type netType)
{
    switch(netType)
    {
    case NET_GSM:
        return "2G";
    case NET_LTE:
    default:
        return "4G";
    }
}

static BOOL app_isUpload(void)
{

    return TRUE;
}

u8 nmea_buffer[1024];
u8 nmea_sentence[1024];
ST_nmeaINFO nmeaINFO;


#if 0
void app_getGnssData(app_cfg_t *ctx)
{
    int i;
    MG_GNSS_Open();

    for (i = 0; i < 1000; i++)
    {
        if (MG_GNSS_GetStatus() == TRUE)
        {
            MG_GNSS_GetNmeaInfo(nmea_buffer, sizeof(nmea_buffer));
            if (TRUE == MG_GNSS_NmeaParse(nmea_buffer, &nmeaINFO))
            {
                if (nmeaINFO.sig)
                {
                    g_app_cfg.gnssData.lat = nmeaINFO.lat;
                    g_app_cfg.gnssData.lon = nmeaINFO.lon;
                    g_app_cfg.gnssData.elv = nmeaINFO.elv;
                    //g_app_cfg.gnssData.view = nmeaINFO.lat;
                    g_app_cfg.gnssData.speed = nmeaINFO.speed;
                    MG_GNSS_Close();
                    break;
                }
            }
        }
    }
}
#else

#define TEST

#ifdef TEST
char *gnss_str = {"$GNRMC,133510.00,A,3107.86242,N,12121.36905,E,0.000,,160523,,,A,V*15\r\n"
             "$GNGGA,133510.00,3107.86242,N,12121.36905,E,1,16,1.01,66.9,M,,M,,*60\r\n"
             "$GNGLL,3107.86242,N,12121.36905,E,133510.00,A,A*75\r\n"
             "$GNGSA,A,3,10,13,29,35,36,34,24,15,20,18,05,23,1.75,1.01,1.43,1*05\r\n"
             "$GNGSA,A,3,01,03,13,06,,,,,,,,,1.75,1.01,1.43,4*07\r\n"
             "$GPGSV,4,1,14,02,02,325,31,05,27,107,42,10,10,307,28,12,03,156,,0*6F\r\n"
             "$GPGSV,4,2,14,13,23,048,22,15,51,033,25,18,61,271,23,20,07,120,24,0*65\r\n"
             "$GPGSV,4,3,14,23,41,322,29,24,72,160,37,29,03,206,24,34,19,146,31,0*6F\r\n"
             "$GPGSV,4,4,14,35,53,168,39,36,31,175,44,0*61\r\n"
             "$GBGSV,3,1,09,01,46,139,42,02,37,237,,03,53,201,31,04,34,122,39,0*7E\r\n"
             "$GBGSV,3,2,09,05,15,256,,06,56,223,29,08,79,022,20,09,40,220,,0*7B\r\n"
             "$GBGSV,3,3,09,13,70,337,16,0*4B\r\n"
             "$GNVTG,,T,,M,0.000,N,0.000,K,A*3D\r\n"};
#endif

double app_nmea_ndeg2degree(double val)
{
    double deg = ((int)(val / 100));
    val = deg + (val - deg * 100) / 60;
    return val;
}

void app_nmea_dtostr(double data, int bit, char *buf)
{
    double precious = 0.0;
    double inter = 0;
    int cout = 1;
    precious = modf(data, &inter);
    for (int i = 0; i < bit; i++)
    {
        cout *= 10;
    }
    int x = (int)inter;
    int y = (int)(precious * cout);
    sprintf(buf, "%d.%d", x, y);
}

static void app_getGnssData(void *param)
{
    app_util_threadSleep(1000, g_app_cfg.bLowPowerModeEn);

    APP_DEBUG("[%d]MQTT get gnss data", __LINE__);
    while (1)
    {
        if (MG_GNSS_GetStatus() == true)
        {
            APP_DEBUG("[%d]MQTT get gnss data", __LINE__);
            MG_GNSS_GetNmeaInfo(nmea_buffer, sizeof(nmea_buffer));

#ifdef TEST
            if (MG_GNSS_NmeaParse((u8 *)gnss_str, &nmeaINFO) == true)
#else
            if (MG_GNSS_NmeaParse(nmea_buffer, &nmeaINFO) == true)
#endif
            //if (MG_GNSS_NmeaParse(nmea_buffer, &nmeaINFO) == true)
            {
                APP_DEBUG("[%d]MQTT get gnss data", __LINE__);
                if (nmeaINFO.sig)
                {
                    APP_DEBUG("[%d]MQTT get gnss data", __LINE__);
                    g_app_cfg.gnssData.lat = nmeaINFO.lat;
                    g_app_cfg.gnssData.lon = nmeaINFO.lon;
                    g_app_cfg.gnssData.elv = nmeaINFO.elv;
                    g_app_cfg.gnssData.view = nmeaINFO.satinfo.inview;
                    g_app_cfg.gnssData.speed = nmeaINFO.speed;

                    //UTC: "2023-01-05 03:22:22"
                    memset((char *)g_app_cfg.gnssData.utc, 0, sizeof(g_app_cfg.gnssData.utc));
                    sprintf((char *)g_app_cfg.gnssData.utc, "%04d-%02d-%02d %02d:%02d:%02d",
                            nmeaINFO.utc.year+1900, nmeaINFO.utc.mon+1, nmeaINFO.utc.day,
                            nmeaINFO.utc.hour, nmeaINFO.utc.min, nmeaINFO.utc.sec);
                    MG_GNSS_Close();
                }
            }
        }
        else
        {
            APP_DEBUG("[%d]MQTT get gnss data", __LINE__);
            MG_GNSS_Open();
        }
        app_util_threadSleep(2*1000, g_app_cfg.bLowPowerModeEn);
    }
}


#endif

void app_getModuleInfo(app_cfg_t *ctx)
{
    int iRet = MG_RET_OK;
    u8 m_buff[64] = {0};

    iRet = MG_SIM_GetIMEI(ctx->netInfo.simId, m_buff, sizeof(m_buff));
    APP_DEBUG("[%d]MQTT get module info, iRet:%d, imei:%s", __LINE__, iRet, m_buff);
    if (iRet > 0)
    {
        memset(ctx->devInfo.imei, 0, sizeof(ctx->devInfo.imei));
        memcpy(ctx->devInfo.imei, (char *)m_buff, sizeof(m_buff));
    }

    iRet = MG_SYSTEM_GetModuleInfo(m_buff, sizeof(m_buff));
    if (iRet > 0)
    {
        memset(ctx->devInfo.ver, 0, sizeof(ctx->devInfo.ver));
        memcpy(ctx->devInfo.ver, (char *)m_buff, sizeof(m_buff));
    }

    ctx->netInfo.netType = NET_LTE;
}

static int app_mqtt_sub_paramDown(app_cfg_t *ctx)
{
    int iRet = MG_RET_OK;
    char mBuff[128] = {0};

    APP_DEBUG("[%d]MQTT sub param down", __LINE__);

    sprintf(mBuff, "%s%s", APP_SUB_DOWN_PARAM, ctx->nvConfig.sn);
    iRet = MG_MQTT_Subscribe(ctx->mqtt.client, mBuff, MQTT_QOS_0, ctx->mqtt.requestTimeout);

    APP_DEBUG("[%d]MQTT sub paramDown, iRet:%d", __LINE__, iRet);
    return MG_RET_OK;
}

//上报数据
static int app_mqtt_pub_uploadDevSN(app_cfg_t *ctx)
{
    int iRet = MG_RET_OK;
    cJSON* cjson_root = NULL;
    char *pMsg = NULL;
    char tmpBuff[128];

    if (MG_RET_OK == iRet)
    {
        APP_DEBUG("[%d]MQTT pub uploadDevSN", __LINE__);
        app_getModuleInfo(ctx);
        //app_getGnssData(ctx);
    }

    if (MG_RET_OK == iRet)
    {
        cJSON* cjson_info = NULL;
        cJSON* cjson_data = NULL;

        APP_DEBUG("[%d]MQTT pub uploadDevSN", __LINE__);
        cjson_root = cJSON_CreateObject();
        if (cjson_root)
        {
            APP_DEBUG("[%d]MQTT pub uploadDevSN", __LINE__);
            // INFO
            cjson_info = cJSON_CreateObject();
            if (cjson_info)
            {
                cJSON_AddStringToObject(cjson_info, "VERSION", (char *)ctx->devInfo.ver);
                cJSON_AddNumberToObject(cjson_info, "BAT", ctx->batteryInfo.capacity);
                cJSON_AddStringToObject(cjson_info, "IMEI", (char *)ctx->devInfo.imei);
                cJSON_AddStringToObject(cjson_info, "DEV_SN", (char *)ctx->nvConfig.sn);
                cJSON_AddStringToObject(cjson_info, "NET_TYPE", app_getNetTypeToString(ctx->netInfo.netType));
                cJSON_AddItemToObject(cjson_root, "INFO", cjson_info);
            }

            // DATA
            cjson_data = cJSON_CreateObject();
            if (cjson_data)
            {
                cJSON_AddNumberToObject(cjson_info, "CSQ", ctx->netInfo.signalLevel);
                cJSON_AddStringToObject(cjson_info, "UTC", (char *)ctx->gnssData.utc);

                memset(tmpBuff, 0, sizeof(tmpBuff));
                double lat = app_nmea_ndeg2degree(ctx->gnssData.lat);
                app_nmea_dtostr(lat, 5, tmpBuff);
                cJSON_AddStringToObject(cjson_info, "LAT", tmpBuff);

                memset(tmpBuff, 0, sizeof(tmpBuff));
                double lon = app_nmea_ndeg2degree(ctx->gnssData.lon);
                app_nmea_dtostr(lon, 5, tmpBuff);
                cJSON_AddStringToObject(cjson_info, "LON", tmpBuff);

                memset(tmpBuff, 0, sizeof(tmpBuff));
                double elv = app_nmea_ndeg2degree(ctx->gnssData.elv);
                app_nmea_dtostr(elv, 5, tmpBuff);
                cJSON_AddStringToObject(cjson_info, "ELV", tmpBuff);

                cJSON_AddNumberToObject(cjson_info, "VIEW", ctx->gnssData.view);

                memset(tmpBuff, 0, sizeof(tmpBuff));
                double speed = app_nmea_ndeg2degree(ctx->gnssData.speed);
                app_nmea_dtostr(speed, 5, tmpBuff);
                cJSON_AddStringToObject(cjson_info, "SPEED", tmpBuff);
                cJSON_AddItemToObject(cjson_root, "DATA", cjson_data);
            }
        }

        iRet = MG_RET_ERR_ENOMEM;
        if (cjson_root && cjson_info && cjson_data)
        {
            APP_DEBUG("[%d]MQTT pub uploadDevSN", __LINE__);
            pMsg = cJSON_Print(cjson_root);
            if (pMsg != NULL)
                iRet = MG_RET_OK;
        }

        cJSON_Delete(cjson_root);
        cjson_root = NULL;
    }

    if (MG_RET_OK == iRet)
    {
        APP_DEBUG("[%d]MQTT pub uploadDevSN", __LINE__);
        memset(tmpBuff, 0, sizeof(tmpBuff));
        sprintf(tmpBuff, "%s%s", APP_PUB_TOPIC_DEV_SN, ctx->nvConfig.sn);

#if 1
        APP_DEBUG("[%d]MQTT pub: topic->%s", __LINE__, tmpBuff);
        APP_DEBUG("[%d]MQTT pub: msg->%s", __LINE__, pMsg);
#endif

#if 1
        iRet = MG_MQTT_Publish(ctx->mqtt.client,
                               tmpBuff,
                               (u8 *)pMsg,
                               strlen(pMsg),
                               MQTT_PUBLISH_DUP_0,
                               MQTT_QOS_0,
                               MQTT_PUBLISH_RETAIN_0,
                               ctx->mqtt.requestTimeout);
#endif
    }

    if (pMsg)
    {
        cJSON_free(pMsg);
        pMsg = NULL;
    }

    APP_DEBUG("[%d]MQTT pub uploadDevSN, iRet:%d", __LINE__, iRet);
    return iRet;
}


void app_mqtt_incoming_cb(void *arg, const u8 *topic, u32 topic_len, const u8 *data, u32 date_len)
{
    APP_DEBUG("[%d]MQTT incoming", __LINE__);
    APP_DEBUG("[%d]MQTT incoming-> topic_len:%d, topic:%s", __LINE__, topic_len , topic);
    APP_DEBUG("[%d]MQTT incoming-> date_len:%d, data:%s", __LINE__, date_len , data);
}

int app_mqtt_connect(app_cfg_t *ctx)
{
    int iRet = MG_RET_OK;

    APP_DEBUG("[%d]MQTT connect", __LINE__);
    if (ctx->mqtt.client == NULL)
    {
        APP_DEBUG("[%d]MQTT connect", __LINE__);
        ctx->mqtt.client = MG_MQTT_Create(&ctx->mqtt.clientInfo);
        if (!ctx->mqtt.client)
        {
            APP_DEBUG("[%d]MQTT connect", __LINE__);
            return MG_RET_ERR_MQTT_ENOMEM;
        }
    }

    if (!MG_MQTT_ClientIsConnected(ctx->mqtt.client))
    {
        APP_DEBUG("[%d]MQTT connect, iRet:%d", __LINE__, iRet);
        iRet = MG_MQTT_SetOpt(ctx->mqtt.client, MQTT_OPT_BIND_CID_SET, &ctx->netInfo.cid, sizeof(ctx->netInfo.cid));
        if (MG_RET_OK == iRet)
        {
            APP_DEBUG("[%d]MQTT connect, iRet:%d", __LINE__, iRet);
            iRet = MG_MQTT_RegisterEx(ctx->mqtt.client, app_mqtt_incoming_cb, NULL);
        }

        if (MG_RET_OK == iRet)
        {
            APP_DEBUG("[%d]MQTT connect, iRet:%d", __LINE__, iRet);
            iRet = MG_MQTT_Connect(ctx->mqtt.client, &ctx->mqtt.connectCtx, ctx->mqtt.connectTimeout);
            if (MG_RET_OK == iRet)
            {
                iRet = app_mqtt_sub_paramDown(ctx);
            }
        }

        ctx->mqtt.state = iRet != MG_RET_OK ? APP_MQTT_DISCONNECTED : APP_MQTT_CONNECTED;
        if(iRet != MG_RET_OK)
        {
            APP_DEBUG("[%d]MQTT connect, iRet:%d", __LINE__, iRet);
            MG_MQTT_Disconnect(ctx->mqtt.client);
        }
    }

    return iRet;
}

static void app_mqtt_thread(void *param)
{
    int iRet = MG_RET_OK;
    app_cfg_t *pApp = &g_app_cfg;

    while(1)
    {
        if (pApp->netState == NET_ACTED)
        {
            iRet = app_mqtt_connect(pApp);
            if (MG_RET_OK == iRet)
            {
                APP_DEBUG("[%d]MQTT upload info", __LINE__);
                // upload info
                if (app_isUpload())
                {
                    app_mqtt_pub_uploadDevSN(pApp);
                    app_util_threadSleep(pApp->nvConfig.nReportCycle *1000, g_app_cfg.bLowPowerModeEn);
                    continue;
                }
            }
        }

        app_util_threadSleep(10 *1000, g_app_cfg.bLowPowerModeEn);
    }

    if (pApp->mqtt.client)
    {
        MG_MQTT_Destroy(pApp->mqtt.client);
        pApp->mqtt.client = NULL;
    }

    APP_DEBUG("[%d]MQTT exit thread", __LINE__);
    app_util_threadSleep(1000, pApp->bLowPowerModeEn);
    MG_OS_ThreadExit();
}

void app_mqtt_start(void)
{
    /*-------------------- MQTT Info --------------------*/
    if (1)
    {
        app_mqtt_cfg_t *p = &g_app_cfg.mqtt;

        APP_DEBUG("[%d]MQTT init param", __LINE__);
        memset(&p->connectCtx,0, sizeof(ST_MqttConnectCtx));
        p->connectCtx.client_id        = "umqtt_client";
        p->connectCtx.hostname         = "47.89.13.131";
        p->connectCtx.port             = 30070;
        //p->connectCtx.username         = "";
        //p->connectCtx.password         = "";
        p->connectCtx.keep_alive       = 300;
        p->connectCtx.clean_session    = 0;

        p->connectTimeout = 100*1000;
        p->requestTimeout = 10*1000;
    }

    //app_util_threadSleep(1000*60, false);
    //app_mqtt_pub_uploadDevSN(&g_app_cfg);

    APP_DEBUG("[%d]MQTT start thread", __LINE__);

    MG_OS_ThreadCreate("gnss", app_getGnssData, NULL, Thread_PRIORITY_NORMAL, 1024 * 8, 4);
    MG_OS_ThreadCreate("app_mqtt", app_mqtt_thread, NULL, Thread_PRIORITY_NORMAL, 1024*4, 50);
}

