#include "app_include.h"
#include "cJSON.h"
#include "mqtt_time.h"
#include "mg_mqtt.h"
#include "mg_sim.h"
#include "mg_network.h"
#include "mg_timer.h"
#include "mg_pm.h"
#include "slpman.h"
#include "ps_lib_api.h"

#define LOG_TAG MAKE_LOG_TAG('U', 'S', 'E', 'R')

#define APP_PUB_TOPIC_DEV_SN    "tank/gpsMsg/"
#define APP_SUB_DOWN_PARAM      "device/ota/"

static char *_app_netTypeToString(app_net_type netType)
{
    switch(netType)
    {
    case NET_TYPE_GSM:
        return "2G";
    case NET_TYPE_LTE:
    default:
        return "4G";
    }
}

void app_getModuleInfo(app_cfg_t *ctx)
{
    int iRet = MG_RET_OK;
    u8 m_buff[64] = {0};
    s32 m_vbat;

    iRet = MG_SIM_GetIMEI(ctx->netInfo.simId, m_buff, sizeof(m_buff));
    if (iRet > 0)
    {
        memset(ctx->devInfo.imei, 0, sizeof(ctx->devInfo.imei));
        memcpy(ctx->devInfo.imei, (char *)m_buff, sizeof(ctx->devInfo.imei));
    }

    {
        u8 signalLevel = 99;
        iRet = MG_NW_GetSignalQuality(ctx->netInfo.simId, &signalLevel);
        ctx->netInfo.signalLevel = signalLevel;
    }

    m_vbat = MG_ADC_getChannelValue(MG_ADC_CHANNEL_VBAT);
    ctx->batteryInfo.capacity = m_vbat;
}

static int app_mqtt_sub_paramDown(app_cfg_t *ctx)
{
    int iRet = MG_RET_OK;
    char mTopic[128] = {0};

    sprintf(mTopic, "%s%s", APP_SUB_DOWN_PARAM, ctx->nvConfig.sn);
    iRet = MG_MQTT_Subscribe(ctx->mqtt.client, mTopic, MQTT_QOS_0, ctx->mqtt.requestTimeout);

    APP_DEBUG("[%d]MQTT sub paramDown, iRet:%d", __LINE__, iRet);
    return MG_RET_OK;
}

//上报数据
static int app_mqtt_pub_uploadDevSN(app_cfg_t *ctx)
{
    int iRet = MG_RET_OK;
    unsigned char mEnd[6] ={0};
    unsigned int m_sendLen = 0;
    int m_iBuff = 0;

    memset(g_app_tmpBuff, 0, sizeof(g_app_tmpBuff));
    m_sendLen += sprintf(g_app_tmpBuff+m_sendLen, "{");

    app_util_jsonDataPack(true, &m_sendLen, ATTR_ARRAY, "INFO", mEnd);
    app_util_jsonDataPack(true, &m_sendLen, ATTR_STRING, "VERSION", (unsigned char *)APP_VER);
    app_util_jsonDataPack(false, &m_sendLen, ATTR_INT, "BAT", (unsigned char *)&ctx->batteryInfo.capacity);
    app_util_jsonDataPack(false, &m_sendLen, ATTR_STRING, "IMEI", (unsigned char *)ctx->devInfo.imei);
    app_util_jsonDataPack(false, &m_sendLen, ATTR_STRING, "DEV_SN", (unsigned char *)ctx->nvConfig.sn);
    app_util_jsonDataPack(false, &m_sendLen, ATTR_STRING, "NET_TYPE", (unsigned char *)_app_netTypeToString(ctx->netInfo.netType));

    app_util_jsonDataPack(false, &m_sendLen, ATTR_ARRAY, "DATA", mEnd);
    app_util_jsonDataPack(true, &m_sendLen, ATTR_INT, "CSQ", (unsigned char *)&ctx->netInfo.signalLevel);
    app_util_jsonDataPack(false, &m_sendLen, ATTR_STRING, "UTC", (unsigned char *)ctx->gnssData.utc);

    app_util_jsonDataPack(false, &m_sendLen, ATTR_DOUBLE, "LAT", (unsigned char *)&ctx->gnssData.lat);
    app_util_jsonDataPack(false, &m_sendLen, ATTR_DOUBLE, "LON", (unsigned char *)&ctx->gnssData.lon);

    m_iBuff = ctx->gnssData.elv;
    app_util_jsonDataPack(false, &m_sendLen, ATTR_INT, "ELV", (unsigned char *)&m_iBuff);

    app_util_jsonDataPack(false, &m_sendLen, ATTR_INT, "VIEW", (unsigned char *)&ctx->gnssData.view);

    m_iBuff = ctx->gnssData.speed;
    app_util_jsonDataPack(false, &m_sendLen, ATTR_INT, "SPEED", (unsigned char *)&m_iBuff);

    m_sendLen += sprintf(g_app_tmpBuff+m_sendLen, "%s}", mEnd);

    {
        char mTopic[128] = {0};

        sprintf(mTopic, "%s%s", APP_PUB_TOPIC_DEV_SN, ctx->nvConfig.sn);
        iRet = MG_MQTT_Publish(ctx->mqtt.client, mTopic,
                               (u8 *)g_app_tmpBuff, strlen(g_app_tmpBuff),
                               MQTT_PUBLISH_DUP_0, MQTT_QOS_2, MQTT_PUBLISH_RETAIN_0, ctx->mqtt.requestTimeout);

#if 0
        APP_DEBUG("[%d]MQTT pub: topic->%s", __LINE__, mTopic);
        APP_DEBUG("[%d]MQTT pub: msg->%s", __LINE__, g_app_tmpBuff);
#endif
    }

    APP_DEBUG("[%d]MQTT pub uploadDevSN, iRet:%d", __LINE__, iRet);
    return iRet;
}


#define TOPIC_MAX_LEN       64

void app_get_downloadParam(const u8 *data, u32 date_len)
{
    cJSON *root = NULL;
    cJSON *item = NULL;
    bool bFota = false;

    root = cJSON_Parse((char *)data);
    if(root == NULL)
    {
        APP_DEBUG("[%d]MQTT download param err", __LINE__);
        return;
    }

    item = cJSON_GetObjectItem(root, "url");
    if (item && item->type == cJSON_String)
    {
        memset((char *)g_app_cfg.fotaFileDownloadUrl, 0, sizeof(g_app_cfg.fotaFileDownloadUrl));
        memcpy((char *)g_app_cfg.fotaFileDownloadUrl, item->valuestring, strlen(item->valuestring));
        bFota = true;
    }

    item = cJSON_GetObjectItem(root, "samplingPeriod");
    if (item)
    {
        if (item->type == cJSON_String)
        {
            g_app_cfg.nvConfig.nReportCycle = atoi(item->valuestring);
        }
        else if (item->type == cJSON_Number)
        {
            g_app_cfg.nvConfig.nReportCycle = item->valueint;
            app_nvmSaveConfig();
        }
    }

    if(root != NULL)
    {
        cJSON_Delete(root);
    }

    if (bFota)
    {
        g_app_cfg.isSysUpdate = bFota;
        app_fota_start();
    }

    APP_DEBUG("[%d]MQTT download param bFota:%d, url:%s", __LINE__, bFota, g_app_cfg.fotaFileDownloadUrl);
    APP_DEBUG("[%d]MQTT download param samplingPeriod:%d", __LINE__, g_app_cfg.nvConfig.nReportCycle);
}

void app_mqtt_incoming_cb(void *arg, const u8 *topic, u32 topic_len, const u8 *data, u32 date_len)
{
    char mTopic[TOPIC_MAX_LEN+1] = {0};

    APP_DEBUG("[%d]MQTT incoming", __LINE__);
    memcpy(mTopic, (char *)topic, topic_len > TOPIC_MAX_LEN ? TOPIC_MAX_LEN : topic_len);

    APP_DEBUG("[%d]MQTT topic_len:%d, topic:%s", __LINE__, topic_len , mTopic);
    APP_DEBUG("[%d]MQTT date_len:%d, data:%s", __LINE__, date_len , data);
    if(strstr(mTopic, APP_SUB_DOWN_PARAM))
    {
        app_get_downloadParam(data, date_len);
    }
}

int app_mqtt_connect(app_cfg_t *ctx)
{
    int iRet = MG_RET_OK;
    u8 cid = ctx->netInfo.cid;

    APP_DEBUG("[%d]MQTT connect", __LINE__);
    if (ctx->mqtt.client == NULL)
    {
        ctx->mqtt.client = MG_MQTT_Create(&ctx->mqtt.clientInfo);
        if (!ctx->mqtt.client)
            return MG_RET_ERR_MQTT_ENOMEM;
    }

    if (MG_MQTT_GetClientState(ctx->mqtt.client) != MQTT_STATE_CONNECT
     && MG_MQTT_GetClientState(ctx->mqtt.client) != MQTT_STATE_DISCONNECTING)
    {
        APP_DEBUG("[%d]MQTT connect, iRet:%d", __LINE__, iRet);
        {
            ctx->mqtt.connectCtx.client_id        = (char *)ctx->nvConfig.sn;
            ctx->mqtt.connectCtx.hostname         = "47.89.13.131";
            ctx->mqtt.connectCtx.port             = 30070;
            ctx->mqtt.connectCtx.username         = "";
            ctx->mqtt.connectCtx.password         = "";
            ctx->mqtt.connectCtx.keep_alive       = 120;
            ctx->mqtt.connectCtx.clean_session    = 0;

            ctx->mqtt.connectTimeout = 60*1000;
            ctx->mqtt.requestTimeout = 30*1000;
        }

        iRet = MG_MQTT_SetOpt(ctx->mqtt.client, MQTT_OPT_BIND_CID_SET, &cid, sizeof(cid));
        if (MG_RET_OK == iRet)
        {
            APP_DEBUG("[%d]MQTT connect, iRet:%d", __LINE__, iRet);
            iRet = MG_MQTT_RegisterEx(ctx->mqtt.client, app_mqtt_incoming_cb, NULL);
        }

        if (MG_RET_OK == iRet)
        {
            APP_DEBUG("[%d]MQTT connect, iRet:%d", __LINE__, iRet);
            iRet = MG_MQTT_Connect(ctx->mqtt.client, &ctx->mqtt.connectCtx, ctx->mqtt.connectTimeout);
            if (MG_RET_OK == iRet)
            {
                iRet = app_mqtt_sub_paramDown(ctx);
            }
        }

        ctx->mqtt.state = iRet != MG_RET_OK ? APP_MQTT_DISCONNECTED : APP_MQTT_CONNECTED;
        if(iRet != MG_RET_OK)
        {
            APP_DEBUG("[%d]MQTT connect, iRet:%d", __LINE__, iRet);
            MG_MQTT_Disconnect(ctx->mqtt.client);

            //MG_MQTT_Destroy(ctx->mqtt.client);
            //ctx->mqtt.client = NULL;
        }
    }

    return iRet;
}

ST_Semaphore *semaphore = NULL;
void app_mqtt_timer_cb(uint8_t id)
{
    MG_OS_SemaphoreRelease(semaphore);
}

void app_mqtt_getData(app_cfg_t *pApp)
{
    app_getModuleInfo(pApp);
    app_gps_getData(pApp);
}

static void app_slp_beforeSleep(void *pdata, slpManLpState state)
{
    // enable aonio latch
    slpManAONIOLatchEn(true);

    APP_DEBUG("[%d]slp_beforeSleep, state:%s", __LINE__, state);
}

static void app_mqtt_thread(void *param)
{
    int iRet = MG_RET_OK;
    app_cfg_t *pApp = &g_app_cfg;
    uint8_t slpmanSlp1Handler = 0xff;
    bool bFirst = true;

    semaphore = MG_OS_SemaphoreCreate(1, 0);
    slpManDeepSlpTimerRegisterExpCb(DEEPSLP_TIMER_ID6, app_mqtt_timer_cb);

    slpManSetPmuSleepMode(true, SLP_SLP2_STATE, false);
    slpManApplyPlatVoteHandle("appslp1", &slpmanSlp1Handler);

    slpManRegisterUsrdefinedBackupCb(app_slp_beforeSleep, NULL);
    slpManPlatVoteDisableSleep(slpmanSlp1Handler, SLP_SLP1_STATE);
    while(1)
    {
        //激活网络
        app_net_doAct(60*1000, pApp);

        //跑业务
        if (strlen((const char *)pApp->nvConfig.sn) > 0 && pApp->netState == NET_ACTED)
        {
            app_mqtt_getData(pApp);
            iRet = app_mqtt_connect(pApp);
            if (MG_RET_OK == iRet)
            {
                APP_DEBUG("[%d]MQTT upload info", __LINE__);
                app_mqtt_pub_uploadDevSN(pApp);
                do
                {
                    app_util_threadSleep(200, pApp->bLowPowerModeEn);
                }while(g_app_cfg.isSysUpdate);

                MG_MQTT_Disconnect(pApp->mqtt.client);
            }

            bFirst = false;
        }

        if (bFirst)
            continue;

        //飞行
        MG_NW_FlightModeEnter(pApp->netInfo.simId, 30*1000);

        slpManPlatVoteEnableSleep(slpmanSlp1Handler, SLP_SLP2_STATE);
        slpManDeepSlpTimerStart(DEEPSLP_TIMER_ID6, pApp->nvConfig.nReportCycle*1000);

        //等唤醒
        MG_OS_SemaphoreAcquireLowPower(semaphore);
        APP_DEBUG("[%d]MQTT start", __LINE__);

        slpManPlatVoteDisableSleep(slpmanSlp1Handler, SLP_SLP2_STATE);
        pApp->netState = NET_NO_ACT;
        MG_NW_FlightModeExit(pApp->netInfo.simId, 30*1000);
    }

    if (pApp->mqtt.client)
    {
        MG_MQTT_Destroy(pApp->mqtt.client);
        pApp->mqtt.client = NULL;
    }

    APP_DEBUG("[%d]MQTT exit thread", __LINE__);
    app_util_threadSleep(1000, pApp->bLowPowerModeEn);
    MG_OS_ThreadExit();
}

void app_mqtt_task(void)
{
    APP_DEBUG("[%d]MQTT start thread", __LINE__);
    //app_mqtt_pub_uploadDevSN(&g_app_cfg);

    app_gps_init();
    MG_OS_ThreadCreate("appMqtt", app_mqtt_thread, NULL, Thread_PRIORITY_NORMAL, 1024*20, 50);
}

