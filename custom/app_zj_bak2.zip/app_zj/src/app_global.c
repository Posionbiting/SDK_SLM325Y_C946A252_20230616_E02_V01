#include "mg_common.h"
#include "mg_os.h"

#define _GLOBAL__
#include "app_global.h"
#undef _GLOBAL__


