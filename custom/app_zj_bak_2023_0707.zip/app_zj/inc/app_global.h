#ifndef _APP_GLOBAL_H
#define _APP_GLOBAL_H
#include "mg_mqtt.h"

#ifndef _GLOBAL__
#define _GLOBAL__ extern
#endif

#define APP_VER         "1.0.1"

typedef enum
{
    APP_MQTT_DISCONNECTED = 0,
    APP_MQTT_CONNECTED
} app_mqtt_state;

typedef enum
{
    NET_TYPE_GSM = 0,
    NET_TYPE_LTE,
} app_net_type;

typedef struct APP_MQTT_CFG_T
{
    int connectTimeout;
    int requestTimeout;

    app_mqtt_state      state;
    ST_MqttClient       *client;
    ST_MqttConnectCtx   connectCtx;
    ST_MqttClientInfo   clientInfo;
} app_mqtt_cfg_t;

// 固件信息
typedef struct APP_DEV_INFO_T
{
    u8 sysVer[48];
    u8 imei[24];
} app_dev_info_t;

// 电池信息
typedef struct APP_BATTERY_INFO_T
{
    s32 capacity;       //电池电量
} app_battery_info_t;

// 网络动态数据
typedef struct APP_NET_INFO_T
{
    u8 simId;
    u8 cid;
    app_net_type netType;
    int signalLevel;

} app_net_info_t;

// GNSS采集数据
typedef struct APP_GNSS_DATA_T
{
    u8 utc[32];         //GPS UTC时间
    u32 view;           //可见卫星数量
    double lat;         //经度
    double lon;         //纬度
    double elv;         //海拔
    double speed;       //速度，kilometers/hour
} app_gnss_data_t;

typedef struct
{
    u8      sn[16];
    u32     nReportCycle;
} app_nv_config;

typedef struct APP_CFG_T
{
    u8                      netState;
    bool                    bLowPowerModeEn;    //低功耗模式

    app_dev_info_t          devInfo;        //固件信息
    app_battery_info_t      batteryInfo;    //电池信息
    app_net_info_t          netInfo;        //网络数据
    app_gnss_data_t         gnssData;       //GNSS采集数据

    app_mqtt_cfg_t  mqtt;

    app_nv_config           nvConfig;

    //fota
    bool isSysUpdate;
    u8 fotaFileDownloadUrl[256];
} app_cfg_t;

_GLOBAL__ char g_app_tmpBuff[1024*10];
_GLOBAL__ app_cfg_t g_app_cfg;

#endif

